
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.mysdice.client.renderer.ShylliceRenderer;
import net.mcreator.mysdice.client.renderer.IceSpiderRenderer;
import net.mcreator.mysdice.client.renderer.FrozenBeastRenderer;
import net.mcreator.mysdice.client.renderer.FrostBiteRenderer;
import net.mcreator.mysdice.client.renderer.EternalGuardianRenderer;
import net.mcreator.mysdice.client.renderer.ChillRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MysdiceModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MysdiceModEntities.FROZEN_BEAST.get(), FrozenBeastRenderer::new);
		event.registerEntityRenderer(MysdiceModEntities.ETERNAL_GUARDIAN.get(), EternalGuardianRenderer::new);
		event.registerEntityRenderer(MysdiceModEntities.CHILL.get(), ChillRenderer::new);
		event.registerEntityRenderer(MysdiceModEntities.FROST_BITE.get(), FrostBiteRenderer::new);
		event.registerEntityRenderer(MysdiceModEntities.ICE_SPIDER.get(), IceSpiderRenderer::new);
		event.registerEntityRenderer(MysdiceModEntities.SHYLLICE.get(), ShylliceRenderer::new);
	}
}
