
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MysdiceModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> SUMMONERSUMMONS = GameRules.register("summonerSummons", GameRules.Category.SPAWNING,
			GameRules.BooleanValue.create(true));
}
