
package net.mcreator.mysdice.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.mysdice.entity.FrozenBeastEntity;
import net.mcreator.mysdice.client.model.Modelicebeast;

public class FrozenBeastRenderer extends MobRenderer<FrozenBeastEntity, Modelicebeast<FrozenBeastEntity>> {
	public FrozenBeastRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelicebeast(context.bakeLayer(Modelicebeast.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(FrozenBeastEntity entity) {
		return new ResourceLocation("mysdice:textures/entities/steve_2.png");
	}
}
