
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.mysdice.client.model.Modelshyllice;
import net.mcreator.mysdice.client.model.Modelicebeast;
import net.mcreator.mysdice.client.model.Modelfrostbite;
import net.mcreator.mysdice.client.model.Modeleternalguardian;
import net.mcreator.mysdice.client.model.Modelcustom_model;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class MysdiceModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelfrostbite.LAYER_LOCATION, Modelfrostbite::createBodyLayer);
		event.registerLayerDefinition(Modeleternalguardian.LAYER_LOCATION, Modeleternalguardian::createBodyLayer);
		event.registerLayerDefinition(Modelcustom_model.LAYER_LOCATION, Modelcustom_model::createBodyLayer);
		event.registerLayerDefinition(Modelicebeast.LAYER_LOCATION, Modelicebeast::createBodyLayer);
		event.registerLayerDefinition(Modelshyllice.LAYER_LOCATION, Modelshyllice::createBodyLayer);
	}
}
