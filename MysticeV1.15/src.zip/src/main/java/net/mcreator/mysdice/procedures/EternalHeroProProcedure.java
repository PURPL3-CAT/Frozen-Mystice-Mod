package net.mcreator.mysdice.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.mysdice.init.MysdiceModMobEffects;

public class EternalHeroProProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return !(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MysdiceModMobEffects.ETERNAL_HERO.get()) : false);
	}
}
