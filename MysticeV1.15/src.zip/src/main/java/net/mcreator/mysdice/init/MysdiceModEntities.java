
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.mysdice.entity.ShylliceEntity;
import net.mcreator.mysdice.entity.MysticeStaffEntity;
import net.mcreator.mysdice.entity.IceSpiderEntity;
import net.mcreator.mysdice.entity.FrozenBeastEntity;
import net.mcreator.mysdice.entity.FrostBiteEntity;
import net.mcreator.mysdice.entity.EternalGuardianEntity;
import net.mcreator.mysdice.entity.ChillEntity;
import net.mcreator.mysdice.MysdiceMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MysdiceModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, MysdiceMod.MODID);
	public static final RegistryObject<EntityType<FrozenBeastEntity>> FROZEN_BEAST = register("frozen_beast",
			EntityType.Builder.<FrozenBeastEntity>of(FrozenBeastEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FrozenBeastEntity::new)

					.sized(0.7f, 2f));
	public static final RegistryObject<EntityType<EternalGuardianEntity>> ETERNAL_GUARDIAN = register("eternal_guardian",
			EntityType.Builder.<EternalGuardianEntity>of(EternalGuardianEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EternalGuardianEntity::new)

					.sized(1.75f, 1.8f));
	public static final RegistryObject<EntityType<ChillEntity>> CHILL = register("chill",
			EntityType.Builder.<ChillEntity>of(ChillEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(ChillEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FrostBiteEntity>> FROST_BITE = register("frost_bite",
			EntityType.Builder.<FrostBiteEntity>of(FrostBiteEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FrostBiteEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<IceSpiderEntity>> ICE_SPIDER = register("ice_spider",
			EntityType.Builder.<IceSpiderEntity>of(IceSpiderEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(IceSpiderEntity::new)

					.sized(1.4f, 0.9f));
	public static final RegistryObject<EntityType<ShylliceEntity>> SHYLLICE = register("shyllice",
			EntityType.Builder.<ShylliceEntity>of(ShylliceEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(ShylliceEntity::new)

					.sized(0.3f, 0.6f));
	public static final RegistryObject<EntityType<MysticeStaffEntity>> MYSTICE_STAFF = register("projectile_mystice_staff",
			EntityType.Builder.<MysticeStaffEntity>of(MysticeStaffEntity::new, MobCategory.MISC).setCustomClientFactory(MysticeStaffEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			FrozenBeastEntity.init();
			EternalGuardianEntity.init();
			ChillEntity.init();
			FrostBiteEntity.init();
			IceSpiderEntity.init();
			ShylliceEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(FROZEN_BEAST.get(), FrozenBeastEntity.createAttributes().build());
		event.put(ETERNAL_GUARDIAN.get(), EternalGuardianEntity.createAttributes().build());
		event.put(CHILL.get(), ChillEntity.createAttributes().build());
		event.put(FROST_BITE.get(), FrostBiteEntity.createAttributes().build());
		event.put(ICE_SPIDER.get(), IceSpiderEntity.createAttributes().build());
		event.put(SHYLLICE.get(), ShylliceEntity.createAttributes().build());
	}
}
