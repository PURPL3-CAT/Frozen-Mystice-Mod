
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.mysdice.MysdiceMod;

public class MysdiceModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, MysdiceMod.MODID);
	public static final RegistryObject<Potion> ETERNAL_HERO_POTION = REGISTRY.register("eternal_hero_potion",
			() -> new Potion(new MobEffectInstance(MysdiceModMobEffects.ETERNAL_HERO.get(), 3600, 1, false, true),
					new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 3600, 1, false, false),
					new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3600, 1, false, false)));
}
