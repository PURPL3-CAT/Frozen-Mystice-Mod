
package net.mcreator.mysdice.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class EternalHeroMobEffect extends MobEffect {
	public EternalHeroMobEffect() {
		super(MobEffectCategory.NEUTRAL, -16724788);
	}

	@Override
	public String getDescriptionId() {
		return "effect.mysdice.eternal_hero";
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
