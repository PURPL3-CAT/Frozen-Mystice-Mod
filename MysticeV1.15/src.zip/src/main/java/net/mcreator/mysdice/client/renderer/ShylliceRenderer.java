
package net.mcreator.mysdice.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.mysdice.entity.ShylliceEntity;
import net.mcreator.mysdice.client.model.Modelshyllice;

public class ShylliceRenderer extends MobRenderer<ShylliceEntity, Modelshyllice<ShylliceEntity>> {
	public ShylliceRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelshyllice(context.bakeLayer(Modelshyllice.LAYER_LOCATION)), 0.7f);
	}

	@Override
	public ResourceLocation getTextureLocation(ShylliceEntity entity) {
		return new ResourceLocation("mysdice:textures/entities/texture_3.png");
	}
}
