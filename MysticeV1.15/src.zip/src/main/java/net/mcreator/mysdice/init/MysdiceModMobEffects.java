
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.mysdice.potion.EternalHeroMobEffect;
import net.mcreator.mysdice.MysdiceMod;

public class MysdiceModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, MysdiceMod.MODID);
	public static final RegistryObject<MobEffect> ETERNAL_HERO = REGISTRY.register("eternal_hero", () -> new EternalHeroMobEffect());
}
