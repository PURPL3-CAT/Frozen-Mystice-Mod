
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ColorHandlerEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.mysdice.block.MystiumBlockBlock;
import net.mcreator.mysdice.block.MysticePortalFrameBlock;
import net.mcreator.mysdice.block.MysticeDimensionPortalBlock;
import net.mcreator.mysdice.block.IceBeastSummonerBlock;
import net.mcreator.mysdice.block.FrostTulipBlock;
import net.mcreator.mysdice.block.EternalWoodWoodBlock;
import net.mcreator.mysdice.block.EternalWoodStairsBlock;
import net.mcreator.mysdice.block.EternalWoodSlabBlock;
import net.mcreator.mysdice.block.EternalWoodPressurePlateBlock;
import net.mcreator.mysdice.block.EternalWoodPlanksBlock;
import net.mcreator.mysdice.block.EternalWoodLogBlock;
import net.mcreator.mysdice.block.EternalWoodLeavesBlock;
import net.mcreator.mysdice.block.EternalWoodFenceGateBlock;
import net.mcreator.mysdice.block.EternalWoodFenceBlock;
import net.mcreator.mysdice.block.EternalWoodButtonBlock;
import net.mcreator.mysdice.block.ColdiumOreBlock;
import net.mcreator.mysdice.block.ColdiumBlockBlock;
import net.mcreator.mysdice.block.AphliceBlock;
import net.mcreator.mysdice.MysdiceMod;

public class MysdiceModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MysdiceMod.MODID);
	public static final RegistryObject<Block> APHLICE = REGISTRY.register("aphlice", () -> new AphliceBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_WOOD = REGISTRY.register("eternal_wood_wood", () -> new EternalWoodWoodBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_LOG = REGISTRY.register("eternal_wood_log", () -> new EternalWoodLogBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_PLANKS = REGISTRY.register("eternal_wood_planks", () -> new EternalWoodPlanksBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_STAIRS = REGISTRY.register("eternal_wood_stairs", () -> new EternalWoodStairsBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_SLAB = REGISTRY.register("eternal_wood_slab", () -> new EternalWoodSlabBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_BUTTON = REGISTRY.register("eternal_wood_button", () -> new EternalWoodButtonBlock());
	public static final RegistryObject<Block> COLDIUM_ORE = REGISTRY.register("coldium_ore", () -> new ColdiumOreBlock());
	public static final RegistryObject<Block> COLDIUM_BLOCK = REGISTRY.register("coldium_block", () -> new ColdiumBlockBlock());
	public static final RegistryObject<Block> MYSTICE_PORTAL_FRAME = REGISTRY.register("mystice_portal_frame", () -> new MysticePortalFrameBlock());
	public static final RegistryObject<Block> MYSTIUM_BLOCK = REGISTRY.register("mystium_block", () -> new MystiumBlockBlock());
	public static final RegistryObject<Block> ICE_BEAST_SUMMONER = REGISTRY.register("ice_beast_summoner", () -> new IceBeastSummonerBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_LEAVES = REGISTRY.register("eternal_wood_leaves", () -> new EternalWoodLeavesBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_FENCE = REGISTRY.register("eternal_wood_fence", () -> new EternalWoodFenceBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_FENCE_GATE = REGISTRY.register("eternal_wood_fence_gate",
			() -> new EternalWoodFenceGateBlock());
	public static final RegistryObject<Block> ETERNAL_WOOD_PRESSURE_PLATE = REGISTRY.register("eternal_wood_pressure_plate",
			() -> new EternalWoodPressurePlateBlock());
	public static final RegistryObject<Block> MYSTICE_DIMENSION_PORTAL = REGISTRY.register("mystice_dimension_portal",
			() -> new MysticeDimensionPortalBlock());
	public static final RegistryObject<Block> FROST_TULIP = REGISTRY.register("frost_tulip", () -> new FrostTulipBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			AphliceBlock.registerRenderLayer();
			MysticePortalFrameBlock.registerRenderLayer();
			IceBeastSummonerBlock.registerRenderLayer();
			FrostTulipBlock.registerRenderLayer();
		}

		@SubscribeEvent
		public static void blockColorLoad(ColorHandlerEvent.Block event) {
			AphliceBlock.blockColorLoad(event);
		}
	}
}
