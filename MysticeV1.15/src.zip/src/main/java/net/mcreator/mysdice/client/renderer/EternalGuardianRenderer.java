
package net.mcreator.mysdice.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.mysdice.entity.EternalGuardianEntity;
import net.mcreator.mysdice.client.model.Modeleternalguardian;

public class EternalGuardianRenderer extends MobRenderer<EternalGuardianEntity, Modeleternalguardian<EternalGuardianEntity>> {
	public EternalGuardianRenderer(EntityRendererProvider.Context context) {
		super(context, new Modeleternalguardian(context.bakeLayer(Modeleternalguardian.LAYER_LOCATION)), 0.75f);
		this.addLayer(new EyesLayer<EternalGuardianEntity, Modeleternalguardian<EternalGuardianEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("mysdice:textures/entities/texture_1.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(EternalGuardianEntity entity) {
		return new ResourceLocation("mysdice:textures/entities/irongolem_1.png");
	}
}
