
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Holder;

import net.mcreator.mysdice.world.features.plants.FrostTulipFeature;
import net.mcreator.mysdice.world.features.ores.ColdiumOreFeature;
import net.mcreator.mysdice.world.features.ores.AphliceFeature;
import net.mcreator.mysdice.world.features.RuinedMysticePortal1Feature;
import net.mcreator.mysdice.MysdiceMod;

import java.util.function.Supplier;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class MysdiceModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, MysdiceMod.MODID);
	private static final List<FeatureRegistration> FEATURE_REGISTRATIONS = new ArrayList<>();
	public static final RegistryObject<Feature<?>> APHLICE = register("aphlice", AphliceFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, AphliceFeature.GENERATE_BIOMES, AphliceFeature::placedFeature));
	public static final RegistryObject<Feature<?>> COLDIUM_ORE = register("coldium_ore", ColdiumOreFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, ColdiumOreFeature.GENERATE_BIOMES, ColdiumOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> RUINED_MYSTICE_PORTAL_1 = register("ruined_mystice_portal_1", RuinedMysticePortal1Feature::feature,
			new FeatureRegistration(GenerationStep.Decoration.SURFACE_STRUCTURES, RuinedMysticePortal1Feature.GENERATE_BIOMES,
					RuinedMysticePortal1Feature::placedFeature));
	public static final RegistryObject<Feature<?>> FROST_TULIP = register("frost_tulip", FrostTulipFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.VEGETAL_DECORATION, FrostTulipFeature.GENERATE_BIOMES, FrostTulipFeature::placedFeature));

	private static RegistryObject<Feature<?>> register(String registryname, Supplier<Feature<?>> feature, FeatureRegistration featureRegistration) {
		FEATURE_REGISTRATIONS.add(featureRegistration);
		return REGISTRY.register(registryname, feature);
	}

	@SubscribeEvent
	public static void addFeaturesToBiomes(BiomeLoadingEvent event) {
		for (FeatureRegistration registration : FEATURE_REGISTRATIONS) {
			if (registration.biomes() == null || registration.biomes().contains(event.getName()))
				event.getGeneration().getFeatures(registration.stage()).add(registration.placedFeature().get());
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			Supplier<Holder<PlacedFeature>> placedFeature) {
	}
}
