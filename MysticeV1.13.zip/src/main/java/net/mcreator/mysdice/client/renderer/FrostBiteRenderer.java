
package net.mcreator.mysdice.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.mysdice.entity.FrostBiteEntity;
import net.mcreator.mysdice.client.model.Modelfrostbite;

public class FrostBiteRenderer extends MobRenderer<FrostBiteEntity, Modelfrostbite<FrostBiteEntity>> {
	public FrostBiteRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelfrostbite(context.bakeLayer(Modelfrostbite.LAYER_LOCATION)), 1.8f);
	}

	@Override
	public ResourceLocation getTextureLocation(FrostBiteEntity entity) {
		return new ResourceLocation("mysdice:textures/wolf.png");
	}
}
