
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mysdice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mysdice.item.RawColdiumItem;
import net.mcreator.mysdice.item.MystiumSwordItem;
import net.mcreator.mysdice.item.MystiumShovelItem;
import net.mcreator.mysdice.item.MystiumPickaxeItem;
import net.mcreator.mysdice.item.MystiumIngotItem;
import net.mcreator.mysdice.item.MystiumHoeItem;
import net.mcreator.mysdice.item.MystiumAxeItem;
import net.mcreator.mysdice.item.MystiumArmorItem;
import net.mcreator.mysdice.item.MysticeSwordItem;
import net.mcreator.mysdice.item.MysticeShovelItem;
import net.mcreator.mysdice.item.MysticePickaxeItem;
import net.mcreator.mysdice.item.MysticeHoeItem;
import net.mcreator.mysdice.item.MysticeGemItem;
import net.mcreator.mysdice.item.MysticeDimensionItem;
import net.mcreator.mysdice.item.MysticeAxeItem;
import net.mcreator.mysdice.item.MysticeArtifactItem;
import net.mcreator.mysdice.item.MysticeArmorItem;
import net.mcreator.mysdice.item.IceSwordItem;
import net.mcreator.mysdice.item.IceShovelItem;
import net.mcreator.mysdice.item.IceShellItem;
import net.mcreator.mysdice.item.IcePickaxeItem;
import net.mcreator.mysdice.item.IceHoeItem;
import net.mcreator.mysdice.item.IceAxeItem;
import net.mcreator.mysdice.item.EternalSwordItem;
import net.mcreator.mysdice.item.EternalShovelItem;
import net.mcreator.mysdice.item.EternalRodItem;
import net.mcreator.mysdice.item.EternalPickaxeItem;
import net.mcreator.mysdice.item.EternalItem;
import net.mcreator.mysdice.item.EternalHoeItem;
import net.mcreator.mysdice.item.EternalAxeItem;
import net.mcreator.mysdice.item.EternalArmorItem;
import net.mcreator.mysdice.item.ColdiumSwordItem;
import net.mcreator.mysdice.item.ColdiumShovelItem;
import net.mcreator.mysdice.item.ColdiumPickaxeItem;
import net.mcreator.mysdice.item.ColdiumNuggetItem;
import net.mcreator.mysdice.item.ColdiumIngotItem;
import net.mcreator.mysdice.item.ColdiumHoeItem;
import net.mcreator.mysdice.item.ColdiumAxeItem;
import net.mcreator.mysdice.item.ColdiumArmorItem;
import net.mcreator.mysdice.MysdiceMod;

public class MysdiceModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MysdiceMod.MODID);
	public static final RegistryObject<Item> APHLICE = block(MysdiceModBlocks.APHLICE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ETERNAL = REGISTRY.register("eternal", () -> new EternalItem());
	public static final RegistryObject<Item> ETERNAL_PICKAXE = REGISTRY.register("eternal_pickaxe", () -> new EternalPickaxeItem());
	public static final RegistryObject<Item> ETERNAL_AXE = REGISTRY.register("eternal_axe", () -> new EternalAxeItem());
	public static final RegistryObject<Item> ETERNAL_SWORD = REGISTRY.register("eternal_sword", () -> new EternalSwordItem());
	public static final RegistryObject<Item> ETERNAL_SHOVEL = REGISTRY.register("eternal_shovel", () -> new EternalShovelItem());
	public static final RegistryObject<Item> ETERNAL_HOE = REGISTRY.register("eternal_hoe", () -> new EternalHoeItem());
	public static final RegistryObject<Item> ETERNAL_ARMOR_HELMET = REGISTRY.register("eternal_armor_helmet", () -> new EternalArmorItem.Helmet());
	public static final RegistryObject<Item> ETERNAL_ARMOR_CHESTPLATE = REGISTRY.register("eternal_armor_chestplate",
			() -> new EternalArmorItem.Chestplate());
	public static final RegistryObject<Item> ETERNAL_ARMOR_LEGGINGS = REGISTRY.register("eternal_armor_leggings",
			() -> new EternalArmorItem.Leggings());
	public static final RegistryObject<Item> ETERNAL_ARMOR_BOOTS = REGISTRY.register("eternal_armor_boots", () -> new EternalArmorItem.Boots());
	public static final RegistryObject<Item> ETERNAL_ROD = REGISTRY.register("eternal_rod", () -> new EternalRodItem());
	public static final RegistryObject<Item> ICE_PICKAXE = REGISTRY.register("ice_pickaxe", () -> new IcePickaxeItem());
	public static final RegistryObject<Item> ICE_AXE = REGISTRY.register("ice_axe", () -> new IceAxeItem());
	public static final RegistryObject<Item> ICE_SWORD = REGISTRY.register("ice_sword", () -> new IceSwordItem());
	public static final RegistryObject<Item> ICE_SHOVEL = REGISTRY.register("ice_shovel", () -> new IceShovelItem());
	public static final RegistryObject<Item> ICE_HOE = REGISTRY.register("ice_hoe", () -> new IceHoeItem());
	public static final RegistryObject<Item> ETERNAL_WOOD_WOOD = block(MysdiceModBlocks.ETERNAL_WOOD_WOOD, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ETERNAL_WOOD_LOG = block(MysdiceModBlocks.ETERNAL_WOOD_LOG, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ETERNAL_WOOD_PLANKS = block(MysdiceModBlocks.ETERNAL_WOOD_PLANKS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ETERNAL_WOOD_LEAVES = block(MysdiceModBlocks.ETERNAL_WOOD_LEAVES, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> ETERNAL_WOOD_STAIRS = block(MysdiceModBlocks.ETERNAL_WOOD_STAIRS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ETERNAL_WOOD_SLAB = block(MysdiceModBlocks.ETERNAL_WOOD_SLAB, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ETERNAL_WOOD_FENCE = block(MysdiceModBlocks.ETERNAL_WOOD_FENCE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> ETERNAL_WOOD_FENCE_GATE = block(MysdiceModBlocks.ETERNAL_WOOD_FENCE_GATE, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> ETERNAL_WOOD_PRESSURE_PLATE = block(MysdiceModBlocks.ETERNAL_WOOD_PRESSURE_PLATE,
			CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> ETERNAL_WOOD_BUTTON = block(MysdiceModBlocks.ETERNAL_WOOD_BUTTON, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> COLDIUM_INGOT = REGISTRY.register("coldium_ingot", () -> new ColdiumIngotItem());
	public static final RegistryObject<Item> COLDIUM_ORE = block(MysdiceModBlocks.COLDIUM_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> COLDIUM_BLOCK = block(MysdiceModBlocks.COLDIUM_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> COLDIUM_PICKAXE = REGISTRY.register("coldium_pickaxe", () -> new ColdiumPickaxeItem());
	public static final RegistryObject<Item> COLDIUM_AXE = REGISTRY.register("coldium_axe", () -> new ColdiumAxeItem());
	public static final RegistryObject<Item> COLDIUM_SWORD = REGISTRY.register("coldium_sword", () -> new ColdiumSwordItem());
	public static final RegistryObject<Item> COLDIUM_SHOVEL = REGISTRY.register("coldium_shovel", () -> new ColdiumShovelItem());
	public static final RegistryObject<Item> COLDIUM_HOE = REGISTRY.register("coldium_hoe", () -> new ColdiumHoeItem());
	public static final RegistryObject<Item> COLDIUM_ARMOR_HELMET = REGISTRY.register("coldium_armor_helmet", () -> new ColdiumArmorItem.Helmet());
	public static final RegistryObject<Item> COLDIUM_ARMOR_CHESTPLATE = REGISTRY.register("coldium_armor_chestplate",
			() -> new ColdiumArmorItem.Chestplate());
	public static final RegistryObject<Item> COLDIUM_ARMOR_LEGGINGS = REGISTRY.register("coldium_armor_leggings",
			() -> new ColdiumArmorItem.Leggings());
	public static final RegistryObject<Item> COLDIUM_ARMOR_BOOTS = REGISTRY.register("coldium_armor_boots", () -> new ColdiumArmorItem.Boots());
	public static final RegistryObject<Item> RAW_COLDIUM = REGISTRY.register("raw_coldium", () -> new RawColdiumItem());
	public static final RegistryObject<Item> MYSTICE_PORTAL_FRAME = block(MysdiceModBlocks.MYSTICE_PORTAL_FRAME, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MYSTICE_DIMENSION = REGISTRY.register("mystice_dimension", () -> new MysticeDimensionItem());
	public static final RegistryObject<Item> ETERNAL_GUARDIAN = REGISTRY.register("eternal_guardian_spawn_egg",
			() -> new ForgeSpawnEggItem(MysdiceModEntities.ETERNAL_GUARDIAN, -16724788, -10066330,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> COLDIUM_NUGGET = REGISTRY.register("coldium_nugget", () -> new ColdiumNuggetItem());
	public static final RegistryObject<Item> CHILL = REGISTRY.register("chill_spawn_egg",
			() -> new ForgeSpawnEggItem(MysdiceModEntities.CHILL, -1, -6710887, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> FROST_BITE = REGISTRY.register("frost_bite_spawn_egg",
			() -> new ForgeSpawnEggItem(MysdiceModEntities.FROST_BITE, -6308930, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ICE_SPIDER = REGISTRY.register("ice_spider_spawn_egg",
			() -> new ForgeSpawnEggItem(MysdiceModEntities.ICE_SPIDER, -12227849, -9982221, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ICE_SHELL = REGISTRY.register("ice_shell", () -> new IceShellItem());
	public static final RegistryObject<Item> SHYLLICE = REGISTRY.register("shyllice_spawn_egg",
			() -> new ForgeSpawnEggItem(MysdiceModEntities.SHYLLICE, -12669477, -11297564, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> MYSTICE_GEM = REGISTRY.register("mystice_gem", () -> new MysticeGemItem());
	public static final RegistryObject<Item> MYSTICE_ARTIFACT = REGISTRY.register("mystice_artifact", () -> new MysticeArtifactItem());
	public static final RegistryObject<Item> ICE_BEAST_SUMMONER = block(MysdiceModBlocks.ICE_BEAST_SUMMONER, CreativeModeTab.TAB_MISC);
	public static final RegistryObject<Item> MYSTICE_ARMOR_HELMET = REGISTRY.register("mystice_armor_helmet", () -> new MysticeArmorItem.Helmet());
	public static final RegistryObject<Item> MYSTICE_ARMOR_CHESTPLATE = REGISTRY.register("mystice_armor_chestplate",
			() -> new MysticeArmorItem.Chestplate());
	public static final RegistryObject<Item> MYSTICE_ARMOR_LEGGINGS = REGISTRY.register("mystice_armor_leggings",
			() -> new MysticeArmorItem.Leggings());
	public static final RegistryObject<Item> MYSTICE_ARMOR_BOOTS = REGISTRY.register("mystice_armor_boots", () -> new MysticeArmorItem.Boots());
	public static final RegistryObject<Item> MYSTICE_PICKAXE = REGISTRY.register("mystice_pickaxe", () -> new MysticePickaxeItem());
	public static final RegistryObject<Item> MYSTICE_AXE = REGISTRY.register("mystice_axe", () -> new MysticeAxeItem());
	public static final RegistryObject<Item> MYSTICE_SWORD = REGISTRY.register("mystice_sword", () -> new MysticeSwordItem());
	public static final RegistryObject<Item> MYSTICE_SHOVEL = REGISTRY.register("mystice_shovel", () -> new MysticeShovelItem());
	public static final RegistryObject<Item> MYSTICE_HOE = REGISTRY.register("mystice_hoe", () -> new MysticeHoeItem());
	public static final RegistryObject<Item> MYSTIUM_INGOT = REGISTRY.register("mystium_ingot", () -> new MystiumIngotItem());
	public static final RegistryObject<Item> MYSTIUM_BLOCK = block(MysdiceModBlocks.MYSTIUM_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MYSTIUM_PICKAXE = REGISTRY.register("mystium_pickaxe", () -> new MystiumPickaxeItem());
	public static final RegistryObject<Item> MYSTIUM_AXE = REGISTRY.register("mystium_axe", () -> new MystiumAxeItem());
	public static final RegistryObject<Item> MYSTIUM_SWORD = REGISTRY.register("mystium_sword", () -> new MystiumSwordItem());
	public static final RegistryObject<Item> MYSTIUM_SHOVEL = REGISTRY.register("mystium_shovel", () -> new MystiumShovelItem());
	public static final RegistryObject<Item> MYSTIUM_HOE = REGISTRY.register("mystium_hoe", () -> new MystiumHoeItem());
	public static final RegistryObject<Item> MYSTIUM_ARMOR_HELMET = REGISTRY.register("mystium_armor_helmet", () -> new MystiumArmorItem.Helmet());
	public static final RegistryObject<Item> MYSTIUM_ARMOR_CHESTPLATE = REGISTRY.register("mystium_armor_chestplate",
			() -> new MystiumArmorItem.Chestplate());
	public static final RegistryObject<Item> MYSTIUM_ARMOR_LEGGINGS = REGISTRY.register("mystium_armor_leggings",
			() -> new MystiumArmorItem.Leggings());
	public static final RegistryObject<Item> MYSTIUM_ARMOR_BOOTS = REGISTRY.register("mystium_armor_boots", () -> new MystiumArmorItem.Boots());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
